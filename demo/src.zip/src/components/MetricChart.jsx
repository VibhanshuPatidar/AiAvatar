import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import { useEffect, useState } from "react";

export default function MetricChart({ label, value }) {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (value == null) return;

    setHistory((prev) =>
      [...prev, { t: Date.now(), v: value }].slice(-30)
    );
  }, [value]);

  const strokeColor = value > 80 ? "#ef4444" : "#3b82f6"; // red / blue

  return (
    <div className="mb-4">
      <div className="text-sm font-semibold mb-1">
        {label}:{" "}
        <span className={value > 80 ? "text-red-500" : "text-blue-500"}>
          {Math.round(value)}
        </span>
      </div>

      <div style={{ width: "100%", height: 120 }}>
        <ResponsiveContainer>
          <LineChart data={history}>
            <XAxis hide />
            <YAxis domain={[0, 100]} hide />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="v"
              stroke={strokeColor}
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
