import { useEffect, useState } from "react";
import { useChat } from "../hooks/useChat";

export default function ChatActions() {
  const { message, chat, onMessagePlayed, loading } = useChat();

  const [action, setAction] = useState(null);

  // Persist action until clicked or new message replaces it
  useEffect(() => {
    

    if (message?.id_response && message?.label_response) {
        if (!message.id_response || !message.label_response || message.id_response === "None" || message.label_response === "None") {
            setAction(null);
            return;
        }
      setAction({
        id: message.id_response,
        label: message.label_response,
      });
    }
  }, [message]);

  if (!action) return null;

  const handleClick = () => {
    setAction(null);        // hide button
    onMessagePlayed();     // advance message queue
    chat(action.id);       // send action id to backend
  };

  return (
    <div className="chat-action-overlay">
      <button
        className="chat-action-btn"
        disabled={loading}
        onClick={handleClick}
      >
        {action.label}
      </button>
    </div>
  );
}
