import { useEffect, useState } from "react";
import { useChat } from "../hooks/useChat";

export default function ChatActions() {
  const { message, chat, onMessagePlayed, loading } = useChat();

  const [action, setAction] = useState(null);
  const [chatStarted, setChatStarted] = useState(false);
  const [chatClosed, setChatClosed] = useState(false);
  const [feedbackGiven, setFeedbackGiven] = useState(false);
  // Detect chat start
  useEffect(() => {
    if (message) {
      setChatStarted(true);
    }
  }, [message]);

  // Handle LLM-provided action (only if chat not closed)
  useEffect(() => {
    if (chatClosed) return;

    if (message?.id_response && message?.label_response) {
        if (!message.id_response || !message.label_response || message.id_response === "None" || message.label_response === "None") {
            setAction(null);
            return;
        }
      setAction({
        id: message.id_response,
        label: message.label_response,
      });
    }
  }, [message, chatClosed]);

  const handleActionClick = (id) => {
    setAction(null);
    onMessagePlayed();
    chat(id);
  };

  const handleCloseChat = () => {
    setAction(null);
    setChatClosed(true);   // 🔑 switch UI state
    onMessagePlayed();
    chat("close_chat");
  };

  const handleFeedback = () => {
    onMessagePlayed();
    setFeedbackGiven(true);
    chat("feedback");
  };

  if (!chatStarted) return null;

  return (
    <div className="chat-action-overlay">
      {/* LLM-driven action (only before chat close) */}
      {!chatClosed && action && (
        <button
          className="chat-action-btn"
          disabled={loading}
          onClick={() => handleActionClick(action.id)}
        >
          {action.label}
        </button>
      )}

      {/* Close Chat button (only before chat close) */}
      {!chatClosed && (
        <button
          className="chat-action-btn secondary"
          disabled={loading}
          onClick={handleCloseChat}
        >
          Close Chat
        </button>
      )}

      {/* Share Feedback button (only after chat close) */}
      {chatClosed && !feedbackGiven && (
        <button
          className="chat-action-btn"
          disabled={loading}
          onClick={handleFeedback}
        >
          Share Feedback
        </button>
      )}
    </div>
  );
}
