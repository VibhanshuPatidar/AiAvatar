import { useDeviceMetrics } from "../hooks/useDeviceMetrics";
import MetricChart from "./MetricChart";

export default function DeviceHealthPanel({ visible }) {
  const metrics = useDeviceMetrics("DEV-001");

  if (!visible || !metrics) return null;

  return (
    <div className="bg-white bg-opacity-60 backdrop-blur-md rounded-lg p-4 mt-2 shadow-lg max-h-[70vh] overflow-y-auto">
      <div className="font-bold mb-3 text-blue-700">
        Live Device Health
      </div>

      <MetricChart label="CPU Usage (%)" value={metrics.cpu_percent} />
      <MetricChart label="Memory Usage (%)" value={metrics.memory_percent} />
      <MetricChart label="Disk Usage (%)" value={metrics.disk_percent} />

      {metrics.gpu_percent != null && (
        <MetricChart label="GPU Usage (%)" value={metrics.gpu_percent} />
      )}

      {metrics.battery_percent != null && (
        <MetricChart
          label={`Battery (${metrics.battery_charging ? "Charging" : "On Battery"})`}
          value={metrics.battery_percent}
        />
      )}

      <MetricChart
        label="Download (KB/s)"
        value={metrics.download_kbps}
      />
      <MetricChart
        label="Upload (KB/s)"
        value={metrics.upload_kbps}
      />
    </div>
  );
}
