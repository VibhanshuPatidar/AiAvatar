// utils.js
// Dynamically list all .glb avatar models in public/models (client-side)

export async function listAvatarModels() {
  // This will only work if you have a backend API or static file manifest
  // For static hosting, you may need to hardcode or generate this list at build time
  // Here, we use a static list as a fallback
  // Replace with API call if available
  return [
    "nerd.glb",

    "robin.glb",

    "ava.glb",
   
    ];
}

export function getDeviceInfo() {
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    cores: navigator.hardwareConcurrency || "unknown",
    memoryGB: navigator.deviceMemory || "unknown",
    screen: {
      width: window.screen.width,
      height: window.screen.height,
      pixelRatio: window.devicePixelRatio
    },
    network: navigator.connection ? {
      effectiveType: navigator.connection.effectiveType,
      downlink: navigator.connection.downlink,
      rtt: navigator.connection.rtt
    } : "unknown",
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
  };
}


export function parseOptions(text) {
  const optionsIndex = text.indexOf("OPTIONS:");
  if (optionsIndex === -1) {
    return { message: text, options: [] };
  }

  const message = text.substring(0, optionsIndex).trim();
  const optionsText = text.substring(optionsIndex);

  const options = optionsText
    .split("\n")
    .filter(line => line.includes("id:"))
    .map(line => {
      const idMatch = line.match(/id:\s*(\w+)/);
      const labelMatch = line.match(/label:\s*(.+)$/);

      return {
        id: idMatch?.[1],
        label: labelMatch?.[1]
      };
    });

  return { message, options };
}
