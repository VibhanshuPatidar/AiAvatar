import { useEffect, useState } from "react";

const backendUrl =
  import.meta.env.VITE_API_URL || "http://localhost:8000";

export function useDeviceMetrics(deviceId = "DEV-001") {
  const [metrics, setMetrics] = useState(null);

  useEffect(() => {
    let interval;

    const fetchMetrics = async () => {
      try {
        const res = await fetch(
          `${backendUrl}/device/metrics?device_id=${deviceId}`
        );
        const data = await res.json();
        setMetrics(data);
      } catch (e) {
        console.error("Failed to fetch device metrics", e);
      }
    };

    fetchMetrics();
    interval = setInterval(fetchMetrics, 2000); // poll every 2s

    return () => clearInterval(interval);
  }, [deviceId]);

  return metrics;
}
