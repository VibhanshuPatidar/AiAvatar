import os
import subprocess
import tempfile
import requests
from pydub import AudioSegment
from .config import settings

def synthesize_speech(text: str, out_wav_path: str) -> None:
    provider = settings.TTS_PROVIDER.lower()
    print(f"Starting TTS synthesis with provider: {provider}")
    if provider == "elevenlabs":
        print(f"ElevenLabs TTS started")
        _synthesize_elevenlabs(text, out_wav_path)
        print(f"ElevenLabs TTS completed: {out_wav_path}")
    elif provider == "piper":
        _synthesize_piper(text, out_wav_path)
    elif provider == "pyttsx3":
        _synthesize_pyttsx3(text, out_wav_path)
    elif provider == "none":
        # Create silent WAV as placeholder
        silence = AudioSegment.silent(duration=2000)  # 2 seconds
        silence.export(out_wav_path, format="wav")
    else:
        print(f"Unsupported TTS provider: {provider}")
        raise RuntimeError(f"Unsupported TTS_PROVIDER: {provider}")
    
# New helper to ensure WAV is standard PCM with configured params
def _normalize_wav(wav_path: str) -> None:
    """
    Convert/normalize an existing audio file to a readable PCM WAV.
    Uses pydub (ffmpeg) first with autodetection; on failure falls back to ffmpeg CLI.
    Configurable via settings:
      - TTS_WAV_SAMPLE_RATE (default 24000)
      - TTS_WAV_CHANNELS (default 1)
      - TTS_WAV_BIT_DEPTH (default 16)
    """
    sr = int(getattr(settings, "TTS_WAV_SAMPLE_RATE", 24000))
    ch = int(getattr(settings, "TTS_WAV_CHANNELS", 1))
    bit_depth = int(getattr(settings, "TTS_WAV_BIT_DEPTH", 16))
    sample_width = max(1, bit_depth // 8)

    if not os.path.exists(wav_path) or os.path.getsize(wav_path) == 0:
        raise RuntimeError("WAV file missing or empty for normalization")

    codec_map = {16: "pcm_s16le", 24: "pcm_s24le"}
    codec = codec_map.get(bit_depth, "pcm_s16le")

    # Try pydub first but don't force format (allow autodetect)
    try:
        audio = AudioSegment.from_file(wav_path)  # auto-detect input container/codec
        audio = audio.set_frame_rate(sr).set_channels(ch).set_sample_width(sample_width)
        audio.export(wav_path, format="wav", codec=codec)
        return
    except Exception as pydub_err:
        # Fallback to ffmpeg CLI conversion for hard-to-decode inputs or malformed headers
        ffmpeg_path = shutil.which("ffmpeg")
        if not ffmpeg_path:
            raise RuntimeError(f"Failed to normalize WAV file: {pydub_err}. ffmpeg CLI not available for fallback.")

        tmp_out = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp_out_path = tmp_out.name
        tmp_out.close()

        cmd = [
            ffmpeg_path,
            "-y",
            "-i", wav_path,
            "-ar", str(sr),
            "-ac", str(ch),
            "-acodec", codec,
            tmp_out_path,
        ]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if proc.returncode != 0:
            if os.path.exists(tmp_out_path):
                os.unlink(tmp_out_path)
            raise RuntimeError(f"Failed to normalize WAV via ffmpeg fallback: {proc.stderr.strip()}")

        # Atomically replace original file with converted output
        os.replace(tmp_out_path, wav_path)

def _synthesize_elevenlabs(text: str, out_wav_path: str) -> None:
    api_key = settings.ELEVENLABS_API_KEY
    voice_id = settings.ELEVENLABS_VOICE_ID
    if not api_key or not voice_id:
        raise RuntimeError("ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID must be set")

    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream"
    headers = {
        "xi-api-key": api_key,
        "accept": "audio/mpeg",
        "Content-Type": "application/json",
    }
    payload = {
        "text": text,
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.5},
    }

    # Create a closed temp file path (Windows-friendly)
    tmp_mp3 = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    mp3_path = tmp_mp3.name
    tmp_mp3.close()

    try:
        # Download streaming MP3 fully to mp3_path
        with requests.post(url, headers=headers, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(mp3_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)

        # Verify non-empty file (guard against server anomalies)
        if os.path.getsize(mp3_path) == 0:
            raise RuntimeError("Downloaded MP3 is empty")

        # Decode MP3 -> WAV
        audio = AudioSegment.from_file(mp3_path, format="mp3")
        audio.export(out_wav_path, format="wav")

    finally:
        # Clean up temp file
        if os.path.exists(mp3_path):
            os.unlink(mp3_path)

def _synthesize_piper(text: str, out_wav_path: str) -> None:
    piper = settings.PIPER_EXECUTABLE
    voice = settings.PIPER_VOICE
    if not piper or not voice:
        raise RuntimeError("PIPER_EXECUTABLE and PIPER_VOICE must be set")

    cmd = [piper, "-m", voice, "-f", out_wav_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    print(f"Running Piper command: {' '.join(cmd)}")
    try:
        stdout, stderr = proc.communicate(text, timeout=120)
        if proc.returncode != 0:
            raise RuntimeError(f"Piper failed: {stderr}")
    except subprocess.TimeoutExpired:
        proc.kill()
        raise RuntimeError("Piper timed out")
    
def _synthesize_pyttsx3(text: str, out_wav_path: str) -> None:
    """Synthesize speech using pyttsx3 and save directly to a WAV file.

    Settings (optional): PYTTSX3_VOICE (id or name), PYTTSX3_RATE (int), PYTTSX3_VOLUME (0.0-1.0)
    """
    try:
        import pyttsx3
    except Exception:
        raise RuntimeError("pyttsx3 is required for the pyttsx3 TTS provider. Install with: pip install pyttsx3")

    engine = pyttsx3.init()

    # Optional settings from configuration
    # Prefer a female voice if not specified
    voice_pref = getattr(settings, "PYTTSX3_VOICE", None)
    if not voice_pref:
        # Try to select a female voice by default
        try:
            engine = pyttsx3.init()
            for v in engine.getProperty("voices"):
                if "female" in v.name.lower() or "female" in v.id.lower():
                    voice_pref = v.id
                    print(voice_pref)
                    break
        except Exception:
            voice_pref = None
    rate = getattr(settings, "PYTTSX3_RATE", None)
    volume = getattr(settings, "PYTTSX3_VOLUME", None)
    engine.setProperty('voice', 'com.apple.voice.compact.en-US.Samantha')
    engine.setProperty("rate", 180)
    # if voice_pref:
    #     for v in engine.getProperty("voices"):
    #         if voice_pref in (v.id, v.name):
    #             engine.setProperty("voice", v.id)
    #             break

    # if rate is not None:
    #     try:
    #         engine.setProperty("rate", int(rate))
    #     except Exception:
    #         pass

    if volume is not None:
        try:
            engine.setProperty("volume", float(volume))
        except Exception:
            pass

    # Save to file and run
    engine.save_to_file(text, out_wav_path)
    engine.runAndWait()
    _normalize_wav(out_wav_path)
    # Verify output exists
    if not os.path.exists(out_wav_path) or os.path.getsize(out_wav_path) == 0:
        raise RuntimeError("pyttsx3 failed to produce audio output")
    
if __name__ == "__main__":
    # Example usage
    synthesize_speech("Hello, this is a test of the TTS system.", "output.wav")
    print("TTS synthesis complete. Output saved to output.wav")
