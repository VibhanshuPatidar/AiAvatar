import psutil
import platform
import requests
import time

try:
    import GPUtil
except ImportError:
    GPUtil = None

BACKEND_URL = "http://localhost:8000/device/telemetry"
DEVICE_ID = "DEV-001"

def get_gpu_usage():
    if not GPUtil:
        return None
    gpus = GPUtil.getGPUs()
    if not gpus:
        return None
    return round(gpus[0].load * 100, 2)

def get_network_usage(prev):
    net = psutil.net_io_counters()
    if not prev:
        return net.bytes_sent, net.bytes_recv, 0, 0

    upload = (net.bytes_sent - prev[0]) / 1024  # KB
    download = (net.bytes_recv - prev[1]) / 1024
    return net.bytes_sent, net.bytes_recv, upload, download

prev_net = None

while True:
    try:
        sent, recv, up_kb, down_kb = get_network_usage(prev_net)
        prev_net = (sent, recv)

        payload = {
            "device_id": DEVICE_ID,
            "os": platform.system(),
            "os_version": platform.version(),
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_percent": psutil.disk_usage("/").percent,
            "battery_percent": (
                psutil.sensors_battery().percent
                if psutil.sensors_battery()
                else None
            ),
            "battery_charging": (
                psutil.sensors_battery().power_plugged
                if psutil.sensors_battery()
                else None
            ),
            "gpu_percent": get_gpu_usage(),
            "upload_kbps": round(up_kb, 2),
            "download_kbps": round(down_kb, 2),
        }

        requests.post(BACKEND_URL, json=payload, timeout=3)
    except Exception:
        pass

    time.sleep(10)
