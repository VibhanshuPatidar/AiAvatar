import psutil
import platform
import requests
import time

try:
    import GPUtil
except ImportError:
    GPUtil = None

BACKEND_URL = "http://localhost:8000/device/telemetry"
DEVICE_ID = "DEV-001"

def get_gpu_usage():
    if not GPUtil:
        return None
    gpus = GPUtil.getGPUs()
    if not gpus:
        return None
    return round(gpus[0].load * 100, 2)

def get_network_usage(prev):
    net = psutil.net_io_counters()

    if not prev:
        return net.bytes_sent, net.bytes_recv, 0, 0

    # bytes per interval
    upload_bytes = net.bytes_sent - prev[0]
    download_bytes = net.bytes_recv - prev[1]

    # convert to Mbps
    upload_mbps = (upload_bytes * 8) / (1024 * 1024)
    download_mbps = (download_bytes * 8) / (1024 * 1024)

    return net.bytes_sent, net.bytes_recv, upload_mbps, download_mbps


prev_net = None

while True:
    try:
        for p in psutil.process_iter(['pid', 'name']):
            try:
                p.cpu_percent(None)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        sent, recv, up_kb, down_kb = get_network_usage(prev_net)
        prev_net = (sent, recv)

        # global CPU percent measured over 1 second
        cpu_total = psutil.cpu_percent(interval=1)

        # collect process stats (memory + cpu) and pick top 10 by memory usage
        process_stats = []
        for p in psutil.process_iter(['pid', 'name']):
            try:
                mem = p.memory_percent()
                cpu = p.cpu_percent(None)
                name = p.info.get('name') or str(p.pid)
                process_stats.append({
                    "name": name,
                    "memory_percent": round(mem, 2),
                    "cpu_percent": round(cpu, 2),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        top_processes = sorted(process_stats, key=lambda x: x["memory_percent"], reverse=True)[:5]
        

        payload = {
            "device_id": DEVICE_ID,
            "os": platform.system(),
            "os_version": platform.version(),
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_percent": psutil.disk_usage("/").percent,
            "battery_percent": (
                psutil.sensors_battery().percent
                if psutil.sensors_battery()
                else None
            ),
            "battery_charging": (
                psutil.sensors_battery().power_plugged
                if psutil.sensors_battery()
                else None
            ),
            "gpu_percent": get_gpu_usage(),
            "upload_mbps": round(up_kb, 2),
            "download_mbps": round(down_kb, 2),
            "top_processes": top_processes,
        }

        requests.post(BACKEND_URL, json=payload, timeout=3)
    except Exception:
        pass

    time.sleep(1)
    print("Sent device telemetry:", payload)
