import psutil
import platform
import requests
import time

BACKEND_URL = "http://localhost:8000/device/telemetry"
DEVICE_ID = "DEV-001"

def collect_metrics():
    return {
        "device_id": DEVICE_ID,
        "os": platform.system(),
        "os_version": platform.version(),
        "cpu_percent": psutil.cpu_percent(interval=1),
        "memory_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage("/").percent,
        "battery": psutil.sensors_battery().percent if psutil.sensors_battery() else None
    }

while True:
    try:
        requests.post(BACKEND_URL, json=collect_metrics(), timeout=3)
    except Exception:
        pass
    time.sleep(10)
